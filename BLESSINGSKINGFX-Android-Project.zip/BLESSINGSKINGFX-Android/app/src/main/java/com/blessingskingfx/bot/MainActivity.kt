package com.blessingskingfx.bot

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Demo-only Deriv connection shell. Rejects non-demo WebSocket URLs and never stores the token. */
class MainActivity : Activity() {
    private val appId = "34XssKZJ5IMWETUg5EAHT"
    private val executor = Executors.newSingleThreadExecutor()
    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private lateinit var tokenInput: EditText
    private lateinit var accountInput: EditText
    private lateinit var symbolInput: EditText
    private lateinit var statusText: TextView
    private lateinit var balanceText: TextView
    private lateinit var connectButton: Button
    private var socket: WebSocket? = null
    private var requestId = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 28, 28, 28) }
        val scroll = ScrollView(this)
        scroll.addView(page)
        setContentView(scroll)
        page.addView(label("BLESSINGSKINGFX AI BOT", 24f, true))
        page.addView(label("Deriv demo connection • Real-money trading is disabled in this build.", 14f))
        page.addView(label("Deriv API token (kept in memory only)", 14f, true))
        tokenInput = EditText(this).apply { hint = "Paste your Deriv API token"; inputType = 129; singleLine = true }
        page.addView(tokenInput, fieldParams())
        page.addView(label("Deriv demo account ID", 14f, true))
        accountInput = EditText(this).apply { hint = "Enter your demo account ID"; singleLine = true }
        page.addView(accountInput, fieldParams())
        page.addView(label("Market symbol", 14f, true))
        symbolInput = EditText(this).apply { setText("R_10"); singleLine = true }
        page.addView(symbolInput, fieldParams())
        connectButton = Button(this).apply { text = "CONNECT DEMO ACCOUNT"; setOnClickListener { connectDemo() } }
        page.addView(connectButton, fieldParams())
        page.addView(Button(this).apply { text = "DISCONNECT"; setOnClickListener { disconnect() } }, fieldParams())
        statusText = label("Status: Not connected", 15f, true)
        balanceText = label("Demo balance: —", 20f, true)
        page.addView(statusText)
        page.addView(balanceText)
        page.addView(label("This starter reads the demo balance and live quotes. Automated order execution is not enabled; it must be implemented and validated separately before any trading is attempted.", 13f))
    }

    private fun label(value: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(0xFF172033.toInt())
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 12, 0, 12)
    }
    private fun fieldParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 }

    private fun connectDemo() {
        val token = tokenInput.text.toString().trim()
        val accountId = accountInput.text.toString().trim()
        val symbol = symbolInput.text.toString().trim()
        if (token.isBlank() || accountId.isBlank() || symbol.isBlank()) { setStatus("Enter token, demo account ID, and symbol."); return }
        connectButton.isEnabled = false
        setStatus("Requesting secure demo connection…")
        executor.execute {
            try {
                val endpoint = URL("https://api.derivws.com/trading/v1/options/accounts/$accountId/otp")
                val conn = (endpoint.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 15000
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Deriv-App-ID", appId)
                    setRequestProperty("Accept", "application/json")
                }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                conn.disconnect()
                if (code !in 200..299) throw IllegalStateException("Deriv rejected the connection (HTTP $code): $body")
                val wsUrl = JSONObject(body).getJSONObject("data").getString("url")
                if (!wsUrl.startsWith("wss://api.derivws.com/") || !wsUrl.contains("/options/ws/demo?") || wsUrl.contains("/options/ws/real")) {
                    throw IllegalStateException("Safety check blocked a non-demo connection. Confirm this is a demo account.")
                }
                runOnUiThread { openSocket(wsUrl, symbol) }
            } catch (e: Exception) {
                runOnUiThread { setStatus("Connection failed: ${e.message ?: "Unknown error"}"); connectButton.isEnabled = true }
            }
        }
    }

    private fun openSocket(wsUrl: String, symbol: String) {
        socket = http.newWebSocket(Request.Builder().url(wsUrl).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                runOnUiThread { setStatus("Connected to Deriv DEMO. Subscribing to balance and $symbol…"); connectButton.isEnabled = true }
                webSocket.send(JSONObject().put("balance", 1).put("subscribe", 1).put("req_id", nextId()).toString())
                webSocket.send(JSONObject().put("ticks", symbol).put("subscribe", 1).put("req_id", nextId()).toString())
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    when (json.optString("msg_type")) {
                        "balance" -> {
                            val b = json.getJSONObject("balance")
                            val amount = b.optDouble("balance")
                            val currency = b.optString("currency", "USD")
                            runOnUiThread { balanceText.text = "Demo balance: %.2f %s".format(amount, currency) }
                        }
                        "tick" -> {
                            val tick = json.getJSONObject("tick")
                            val quote = tick.optDouble("quote")
                            val name = tick.optString("symbol", symbol)
                            runOnUiThread { setStatus("DEMO connected • $name quote: $quote") }
                        }
                        "error" -> {
                            val message = json.optJSONObject("error")?.optString("message") ?: "Deriv API error"
                            runOnUiThread { setStatus("Deriv: $message") }
                        }
                    }
                } catch (_: Exception) { runOnUiThread { setStatus("Received an unreadable response from Deriv.") } }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread { setStatus("WebSocket disconnected: ${t.message ?: "connection error"}"); connectButton.isEnabled = true }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                runOnUiThread { setStatus("Disconnected: $reason"); connectButton.isEnabled = true }
            }
        })
    }
    private fun nextId() = requestId++
    private fun setStatus(message: String) { statusText.text = "Status: $message" }
    private fun disconnect() {
        socket?.close(1000, "User disconnected"); socket = null
        balanceText.text = "Demo balance: —"; setStatus("Disconnected"); connectButton.isEnabled = true
    }
    override fun onDestroy() {
        disconnect(); executor.shutdownNow(); http.dispatcher.executorService.shutdown(); super.onDestroy()
    }
}
