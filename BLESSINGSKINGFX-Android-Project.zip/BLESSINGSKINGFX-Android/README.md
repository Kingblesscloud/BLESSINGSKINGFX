# BLESSINGSKINGFX AI BOT — Android starter

This is a native Android Kotlin project with a GitHub Actions workflow that builds a debug APK.

## Current functionality
- Deriv API token entered locally and held in memory only (not saved to disk or committed).
- Requests an authenticated Deriv Options WebSocket URL through the OTP REST endpoint.
- Rejects any endpoint that is not the Deriv **demo** WebSocket endpoint.
- Subscribes to demo balance and market ticks.
- Disconnect button.

## Important status
This starter does **not** place trades. Automated order execution and a trading strategy have not been implemented or validated. Do not use a real-account token. The app intentionally blocks the real WebSocket endpoint.

## Build
Push these files to the `main` branch of `Kingblesscloud/BLESSINGSKINGFX`. GitHub Actions will run `Android APK Build`. Open the workflow run and download the `BLESSINGSKINGFX-demo-debug-apk` artifact.

## Deriv setup
Use a Deriv API token with the `trade` permission and a demo account ID. The app ID is configured in `MainActivity.kt`. Never commit or share your API token.
